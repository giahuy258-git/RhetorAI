// Chờ cho toàn bộ nội dung trang được tải
document.addEventListener("DOMContentLoaded", () => {

    // --- XỬ LÝ API ĐĂNG KÝ ---
    const registerForm = document.getElementById("register-form");
    if (registerForm) {
        registerForm.addEventListener("submit", async(e) => {
            e.preventDefault(); // Ngăn form gửi theo cách truyền thống

            const name = document.getElementById("register-name").value;
            const email = document.getElementById("register-email").value;
            const password = document.getElementById("register-password").value;
            const passwordConfirm = document.getElementById("register-password-confirm").value;
            const messageDiv = document.getElementById("register-message");

            if (password !== passwordConfirm) {
                messageDiv.innerHTML = `<div class="alert alert-danger">Mật khẩu không khớp!</div>`;
                return;
            }

            // Gửi dữ liệu đến API Endpoint /api/register trong Flask
            try {
                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ name: name, email: email, password: password }),
                });

                const data = await response.json();

                if (response.ok) {
                    // Thành công
                    messageDiv.innerHTML = `<div class="alert alert-success">${data.message}</div>`;
                    // TODO: Chuyển hướng người dùng đến trang đăng nhập
                    setTimeout(() => {
                        window.location.href = '/dang-nhap';
                    }, 2000);
                } else {
                    // Thất bại
                    messageDiv.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                }
            } catch (error) {
                console.error('Lỗi đăng ký:', error);
                messageDiv.innerHTML = `<div class="alert alert-danger">Đã có lỗi xảy ra. Vui lòng thử lại.</div>`;
            }
        });
    }

    // --- XỬ LÝ API ĐĂNG NHẬP ---
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", async(e) => {
            e.preventDefault();

            const email = document.getElementById("login-email").value;
            const password = document.getElementById("login-password").value;
            const messageDiv = document.getElementById("login-message");

            // Gửi dữ liệu đến API Endpoint /api/login trong Flask
            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email: email, password: password }),
                });

                const data = await response.json();

                if (response.ok) {
                    // Thành công
                    messageDiv.innerHTML = `<div class="alert alert-success">${data.message}</div>`;
                    // TODO: Lưu token (nếu có) và chuyển hướng đến trang chatbot
                    setTimeout(() => {
                        window.location.href = '/chatbot';
                    }, 1500);
                } else {
                    // Thất bại
                    messageDiv.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                }
            } catch (error) {
                console.error('Lỗi đăng nhập:', error);
                messageDiv.innerHTML = `<div class="alert alert-danger">Đã có lỗi xảy ra. Vui lòng thử lại.</div>`;
            }
        });
    }
});