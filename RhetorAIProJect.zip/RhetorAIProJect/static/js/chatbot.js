(function(){
  const DEFAULT_SECS = 5*60;
  let micStream, mediaRecorder, micInterval, micTime = 0, isRecording = false;

  const step1=document.getElementById('step-1'),
        step2=document.getElementById('step-2'),
        step3=document.getElementById('step-3'),
        debateUI=document.getElementById('debate-ui'),
        topicListEl=document.getElementById('topic-list'),
        topicTitleEl=document.getElementById('topic-title'),
        messagesEl=document.getElementById('messages'),
        chatForm=document.getElementById('chatbot-form'),
        chatInput=document.getElementById('chat-input'),
        micBtn=document.getElementById('mic-btn'),
        micTimerEl=document.getElementById('mic-timer'),
        voiceControls=document.getElementById('voice-controls'),
        avatarAi=document.getElementById('avatar-ai'),
        avatarUser=document.getElementById('avatar-user'),
        timerAiEl=document.getElementById('timer-ai'),
        timerUserEl=document.getElementById('timer-user'),
        roleAiEl=document.getElementById('role-ai'),
        roleUserEl=document.getElementById('role-user'),
        startBtn=document.getElementById('start-debate-btn'),
        pauseBtn=document.getElementById('pause-debate-btn'),
        endBtn=document.getElementById('end-debate-btn'),
        themeToggle=document.getElementById('theme-toggle');

  let state={mode:'chat',side:null,topicTitle:null,timers:{ai:DEFAULT_SECS,user:DEFAULT_SECS},activeSpeaker:null,paused:true,timerInterval:null};

  /* THEME */
  function initTheme(){
    const saved=localStorage.getItem('theme')||'light';
    document.documentElement.dataset.theme=saved;
    themeToggle.textContent=saved==='dark'?'☀️ Light':'🌙 Dark';
  }
  initTheme();
  themeToggle.onclick=()=>{
    const cur=document.documentElement.dataset.theme;
    const next=cur==='dark'?'light':'dark';
    document.documentElement.dataset.theme=next;
    localStorage.setItem('theme',next);
    themeToggle.textContent=next==='dark'?'☀️ Light':'🌙 Dark';
  };

  function show(step){
    [step1,step2,step3].forEach(s=>s.classList.remove('active'));
    if(step===1)step1.classList.add('active');
    if(step===2)step2.classList.add('active');
    if(step===3)step3.classList.add('active');
    debateUI.style.display=(step==='debate')?'block':'none';
    if(step==='debate')scrollBottom();
  }

  const topics=[
    {id:1,title:"AI có thay thế con người?"},
    {id:2,title:"Mạng xã hội có làm con người cô lập?"}
  ];
  topicListEl.innerHTML=topics.map(t=>`<button class="btn btn-outline-secondary m-2">${t.title}</button>`).join('');
  [...topicListEl.children].forEach((b,i)=>b.onclick=()=>{
    state.topicTitle=topics[i].title;
    show(2);
  });

  document.querySelectorAll('.mode-btn').forEach(b=>b.onclick=()=>{
    state.mode=b.dataset.mode;
    toggleModeUI();
    show(3);
  });
  document.getElementById('back-to-step1').onclick=()=>show(1);
  document.getElementById('back-to-step2').onclick=()=>show(2);

  document.querySelectorAll('.side-btn').forEach(b=>b.onclick=()=>{
    state.side=b.dataset.side;
    setRoles();
    openDebate();
  });

  function setRoles(){
    if(state.side==='pro'){
      roleUserEl.textContent='Ủng hộ';
      roleAiEl.textContent='Phản đối';
    } else {
      roleUserEl.textContent='Phản đối';
      roleAiEl.textContent='Ủng hộ';
    }
  }

  function openDebate(){
    topicTitleEl.textContent=state.topicTitle||'[Chưa chọn]';
    show('debate');
    messagesEl.innerHTML='';
    resetTimers();
    updateTimers();
    toggleModeUI();
  }

  function toggleModeUI(){
    if(state.mode==='voice'){
      chatForm.style.display='none';voiceControls.style.display='flex';
    }else{
      chatForm.style.display='flex';voiceControls.style.display='none';
    }
    scrollBottom();
  }


  function secToMMSS(s){
    const mm=Math.floor(s/60).toString().padStart(2,'0');
    const ss=(s%60).toString().padStart(2,'0');
    return mm+':'+ss;
  }

  function updateTimers(){
    timerAiEl.textContent=secToMMSS(state.timers.ai);
    timerUserEl.textContent=secToMMSS(state.timers.user);
  }

  function startTimerLoop(){
    if(state.timerInterval)return;
    state.timerInterval=setInterval(()=>{
      if(state.paused||!state.activeSpeaker)return;
      const w=state.activeSpeaker;
      if(state.timers[w]>0){
        state.timers[w]--;
        updateTimers();
      }
    },1000);
  }

  function stopTimerLoop(){
    if(state.timerInterval){
      clearInterval(state.timerInterval);
      state.timerInterval=null;
    }
  }

  function resetTimers(){
    state.timers={ai:DEFAULT_SECS,user:DEFAULT_SECS};
    updateTimers();
  }

  function resumeTimer(){
    state.paused=false;
    if(!state.timerInterval)startTimerLoop();
  }

  function setSpeaking(w){
    [avatarAi,avatarUser].forEach(a=>a.classList.remove('speaking','user-glow','ai-glow'));
    if(w==='ai'){avatarAi.classList.add('speaking','ai-glow');}
    if(w==='user'){avatarUser.classList.add('speaking','user-glow');}
    state.activeSpeaker=w;
  }

  chatForm.onsubmit=e=>{
    e.preventDefault();
    const txt=chatInput.value.trim();
    if(!txt)return;
    resumeTimer();setSpeaking('user');
    appendMsg('user',txt);chatInput.value='';
    setTimeout(()=>{
      setSpeaking('ai');
      appendMsg('ai','AI phản biện: '+txt);
      setTimeout(()=>setSpeaking('user'),500);
    },1000);
  };

  micBtn.onclick=()=>{if(isRecording)stopMic();else startMic();};

  async function startMic(){
    try{
      micStream=await navigator.mediaDevices.getUserMedia({audio:true});
      mediaRecorder=new MediaRecorder(micStream);
      mediaRecorder.start();
      micBtn.classList.add('recording');
      micBtn.setAttribute('aria-pressed','true');
      micTime=0;
      isRecording=true;
      setSpeaking('user');
      resumeTimer();
      micInterval=setInterval(()=>{
        micTime++;
        micTimerEl.textContent=secToMMSS(micTime);
      },1000);
    }catch(e){alert('Không thể truy cập micro.');}
  }

  function stopMic(){
    if(mediaRecorder&&isRecording){
      mediaRecorder.stop();
      micStream.getTracks().forEach(t=>t.stop());
    }
    clearInterval(micInterval);
    micBtn.classList.remove('recording');
    isRecording=false;
    appendMsg('user','🎤 Bạn vừa nói ('+secToMMSS(micTime)+')');
    setSpeaking('ai');
    setTimeout(()=>{
      appendMsg('ai','AI phản hồi âm thanh của bạn.');
      setSpeaking('user');
    },1000);
    micTimerEl.textContent='00:00';
  }

  /* Controls */
  startBtn.onclick = () => {
    resumeTimer();
    setSpeaking('user');
    startTimerLoop();
  };

  pauseBtn.onclick = () => {
    state.paused = true;
  };

  endBtn.onclick = () => {
    stopTimerLoop();
    state.paused = true;
    setSpeaking(null);
    appendMsg('ai', '✨ Cuộc tranh biện đã kết thúc!');
  };

  /* Resume timer when user sends or records after pause */
  chatForm.addEventListener('submit', ()=> {
    if(state.paused){ resumeTimer(); }
  });
  micBtn.addEventListener('click', ()=> {
    if(state.paused){ resumeTimer(); }
  });

  /* Append message helper */
  function appendMsg(who, text) {
    const div = document.createElement('div');
    div.className = 'msg ' + who;
    div.textContent = text;
    messagesEl.appendChild(div);
    scrollBottom();
  }

  /* Scroll only inside messages box (avoid pushing footer) */
  function scrollBottom() {
    try {
      messagesEl.scrollTop = messagesEl.scrollHeight;
    } catch (e) {}
  }

  /* --- AUTO OPEN FROM URL PARAM ?topic=... --- */
  (function autoOpenFromURL(){
    const params = new URLSearchParams(window.location.search);
    const topicFromURL = params.get('topic');
    if (topicFromURL) {
      state.topicTitle = topicFromURL;
      if (topicTitleEl) topicTitleEl.textContent = topicFromURL;
      show(2); // Nhảy thẳng sang chọn loại hình
      toggleModeUI();
      return; // Dừng lại để không chạy show(1) phía dưới
    }
  })();




  /* Init */
  show(1);
  updateTimers();
  toggleModeUI();

})();
