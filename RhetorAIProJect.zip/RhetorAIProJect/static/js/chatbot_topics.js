// chatbot_topics.js
(function(){
  const grid = document.getElementById('topics-grid');

  // mock topic list
  const topics = [
    { id: 1, title: "AI có thay thế con người?" },
    { id: 2, title: "Mạng xã hội có làm con người cô lập?" },
    { id: 3, title: "Công nghệ ảnh hưởng đến tư duy trẻ em?" },
    { id: 4, title: "Học trực tuyến có hiệu quả hơn truyền thống?" },
    { id: 5, title: "Biến đổi khí hậu là do con người gây ra?" },
    { id: 6, title: "Nên đánh thuế mạng xã hội để kiểm soát thông tin?" }
  ];

  // render topics
  topics.forEach(t => {
    const card = document.createElement('div');
    card.className = 'topic-card';
    card.textContent = t.title;
    card.onclick = () => {
      // Redirect to /debate and pass topic via query string.
      // Backend route /debate will render chatbot.html and we read the topic there.
      const url = '/debate?topic=' + encodeURIComponent(t.title);
      // Use location.assign so that browser history works (back button)
      location.assign(url);
    };
    grid.appendChild(card);
  });
})();
