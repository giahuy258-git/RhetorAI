import os
from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from functools import wraps

app = Flask(__name__)

# --- CẤU HÌNH BẮT BUỘC ---
# Cần đặt một khóa bí mật (secret key) để Flask sử dụng 'session'
# Bạn nên thay đổi 'your_very_secret_key_here' thành một chuỗi ngẫu nhiên
app.secret_key = os.environ.get('SECRET_KEY', 'your_very_secret_key_here_fallback')


# =================================================================
# == DECORATOR BẢO VỆ ADMIN
# =================================================================
def admin_role_required(allowed_roles):
    """
    Decorator này kiểm tra xem admin đã đăng nhập chưa VÀ
    có vai trò (role) được phép hay không.
    Nó kiểm tra 'admin_id' trong session.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # 1. Kiểm tra xem admin đã đăng nhập chưa
            if 'admin_id' not in session:
                return redirect(url_for('admin_login')) # Chuyển về trang login admin
            
            # 2. Kiểm tra vai trò (role) của admin
            if session.get('admin_role') not in allowed_roles:
                # Nếu không có quyền, về trang admin index (trang này sẽ tự điều hướng)
                return redirect(url_for('admin_index')) 
            
            # 3. Mọi thứ OK, cho phép truy cập
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# =================================================================
# == ROUTES CÔNG KHAI (Dành cho Người dùng)
# =================================================================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/gioi-thieu')
def about():
    return render_template('about.html')

@app.route('/lien-he')
def contact():
    return render_template('contact.html')

# --- Routes cho xác thực NGƯỜI DÙNG CÔNG KHAI ---
@app.route('/dang-nhap')
def login():
    """Trang đăng nhập/đăng ký cho NGƯỜI DÙNG CÔNG KHAI."""
    return render_template('auth/login.html')

@app.route('/dang-ky')
def register():
    """Trang đăng nhập/đăng ký cho NGƯỜI DÙNG CÔNG KHAI."""
    # Chuyển hướng đến trang login vì đã gộp chung 2 form
    return redirect(url_for('login'))

# --- Routes cho Blog ---
@app.route('/blog')
def blog():
    return render_template('blog/blog.html')

@app.route('/blog/<int:post_id>')
def blog_detail(post_id):
    return render_template('blog/blog_detail.html', post_id=post_id)

# --- Routes cho Chatbot (Cần đăng nhập người dùng) ---
@app.route('/chatbot')
def chatbot():
    # TODO: Thêm logic kiểm tra 'user_id' trong session
    # if 'user_id' not in session:
    #     return redirect(url_for('login'))
    return render_template('chatbot/chatbot.html')

# Danh sách chủ đề (public)
@app.route('/topics')
def topics():
    # render page danh sách chủ đề
    return render_template('chatbot/topics.html')

# Route "debate" để nhận param topic và hiển thị trang tranh biện (chatbot)
@app.route('/debate')
def debate():
    # Lấy topic từ query param (ví dụ: /debate?topic=AI%20có%20thay%20thế%20con%20người%3F)
    selected_topic = request.args.get('topic')
    # Gọi template chatbot, truyền topic (nếu có) để JS/HTML có thể đọc
    return render_template('chatbot/chatbot.html', topic=selected_topic)


@app.route("/history")
def history():
    # dữ liệu giả để test
    debates = [
        {"topic": "AI có thay thế con người?", "result": "Thắng", "mode": "Chat", "date": "2025-10-27"},
        {"topic": "Mạng xã hội có làm con người cô lập?", "result": "Thua", "mode": "Voice", "date": "2025-10-26"},
        {"topic": "Robot có cảm xúc không?", "result": "Hòa", "mode": "Chat", "date": "2025-10-25"},
    ]
    return render_template("chatbot/history.html", debates=debates)

@app.route("/ranking")
def ranking():
    players = [
        {"id": 1, "name": "Nguyễn Minh Khang", "points": 1520, "rank": "Bạch Kim", "avatar": "AVT3.jpg", "win_rate": 82, "matches": 24},
        {"id": 2, "name": "Trần Hoàng Nam", "points": 1470, "rank": "Vàng", "avatar": "AVT2.jpg", "win_rate": 77, "matches": 21},
        {"id": 3, "name": "Lê Hồng Hà", "points": 1380, "rank": "Bạc", "avatar": "AVT1.png", "win_rate": 74, "matches": 19},
        {"id": 4, "name": "Phạm Thanh Bình", "points": 1330, "rank": "Đồng", "avatar": "AVT4.jpg", "win_rate": 68, "matches": 16},
        {"id": 5, "name": "Ngô Minh Tú", "points": 1290, "rank": "Đồng", "avatar": "AVT5.jpg", "win_rate": 64, "matches": 15},
    ]
    return render_template("chatbot/ranking.html", players=players)


@app.route('/results')
def results():
    stats = {
        "total": 25,
        "win_rate": 64,
        "total_time": 132,
        "popular_mode": "💬 Chat"
    }

    results = {
        "win": 16,
        "loss": 7,
        "draw": 2
    }

    return render_template('chatbot/results.html', stats=stats, results=results)





# =================================================================
# == API ENDPOINTS (Dành cho Người dùng)
# =================================================================

@app.route('/api/register', methods=['POST'])
def api_register():
    """API để NGƯỜI DÙNG CÔNG KHAI đăng ký."""
    data = request.json
    # TODO: Xử lý logic đăng ký (lưu vào CSDL bảng 'Users')
    # ...
    
    # Giả lập thành công
    return jsonify({'status': 'success', 'message': 'Đăng ký thành công!'}), 201

@app.route('/api/login', methods=['POST'])
def api_login():
    """API để NGƯỜI DÙNG CÔNG KHAI đăng nhập."""
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    # TODO: Xử lý logic đăng nhập (kiểm tra CSDL bảng 'Users')
    # ...
    
    # Giả lập đăng nhập thành công
    if email == "user@test.com" and password == "123":
        # Lưu vào session của NGƯỜI DÙNG
        session['user_id'] = 123 # ID từ CSDL
        session['user_email'] = email
        return jsonify({'status': 'success', 'message': 'Đăng nhập thành công!'}), 200
    else:
        return jsonify({'status': 'error', 'message': 'Sai email hoặc mật khẩu'}), 401

@app.route('/api/logout')
def api_logout():
    """API để NGƯỜI DÙNG CÔNG KHAI đăng xuất."""
    session.pop('user_id', None)
    session.pop('user_email', None)
    return redirect(url_for('index'))

@app.route('/api/chatbot', methods=['POST'])
def api_chatbot():
    """API cho chatbot."""
    # if 'user_id' not in session:
    #     return jsonify({'status': 'error', 'message': 'Chưa xác thực'}), 401
        
    data = request.json
    message = data.get('message')
    # TODO: Xử lý logic AI/chatbot ở đây
    ai_response = f"Đây là phản hồi của AI cho: '{message}'"
    return jsonify({'status': 'success', 'response': ai_response})


# =================================================================
# == KHU VỰC ADMIN RIÊNG BIỆT
# =================================================================

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Trang đăng nhập RIÊNG cho Admin."""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # --- LOGIC KIỂM TRA TÀI KHOẢN ADMIN ---
        # TODO: Thay thế bằng truy vấn CSDL (ví dụ: bảng 'AdminAccounts')
        
        # Ví dụ giả lập:
        if email == 'super@admin.com' and password == 'adminpass123':
            session['admin_id'] = 1
            session['admin_email'] = email
            session['admin_role'] = 'super_admin'
            return redirect(url_for('admin_index'))
        
        elif email == 'editor@admin.com' and password == 'editorpass123':
            session['admin_id'] = 2
            session['admin_email'] = email
            session['admin_role'] = 'editor'
            return redirect(url_for('admin_index'))
        
        else:
            # Đăng nhập thất bại, quay lại trang login
            return render_template('admin/admin_login.html', error='Sai email hoặc mật khẩu')
    
    # Nếu là GET, chỉ hiển thị trang login
    return render_template('admin/admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    """Trang đăng xuất RIÊNG cho Admin."""
    # Chỉ xóa các session key của admin
    session.pop('admin_id', None)
    session.pop('admin_email', None)
    session.pop('admin_role', None)
    return redirect(url_for('admin_login'))


# --- CÁC TRANG ADMIN ĐƯỢC BẢO VỆ ---

@app.route('/admin')
@admin_role_required(allowed_roles=['super_admin', 'admin', 'editor'])
def admin_index():
    """Trang điều hướng chính của Admin."""
    # Chuyển hướng dựa trên vai trò
    if session['admin_role'] == 'super_admin':
        return redirect(url_for('admin_users'))
    else:
        return redirect(url_for('admin_topics'))

@app.route('/admin/users')
@admin_role_required(allowed_roles=['super_admin']) # CHỈ super_admin
def admin_users():
    """Trang quản lý người dùng (tạo tài khoản admin/editor khác)."""
    return render_template('admin/admin_users.html')

@app.route('/admin/topics')
@admin_role_required(allowed_roles=['super_admin', 'admin', 'editor']) # Cả 3 vai trò
def admin_topics():
    """Trang quản lý chủ đề tranh biện."""
    return render_template('admin/admin_topics.html')

# TODO: Tạo các API riêng cho admin (ví dụ: /api/admin/create_user)
# và cũng bảo vệ chúng bằng @admin_role_required


# =================================================================
# == CHẠY ỨNG DỤNG
# =================================================================

if __name__ == '__main__':
    app.run(debug=True)